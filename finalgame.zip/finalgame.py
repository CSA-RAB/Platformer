#Ryan Blaschke
#Advanced Computer Programming
#3/27/17
#final game
#version 0.5.0
#Platformer in which you keep jumping until you die/fall

import pygame, sys, random, os, time             #necessary imports
from pygame.locals import *

########################

########################################################################
'''This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.'''
##############################################################################

pygame.init()   #start pygame

BLACK  = (  0,   0,   0)   #colors, for later use
BLUE   = (  0,   0, 255)
LTGREEN= (  0, 255,   0)
LTBLUE = (  0, 255, 255)
WHITE  = (255, 255, 255)
YELLOW = (255, 255,   0)
PINK   = (255,   0, 255)
LTRED  = (255,   0,   0)
DKBLUE = (  0,   0, 100)
GREEN  = (  0, 100,   0)
MAROON = (100,   0,   0)
DKGREEN= (100, 100,   0)
PURPLE = (100,   0, 100)
DKGRAY = (100, 100, 100)
LTGRAY = (200, 200, 200)
RED    = (200,   0,   0)
LIMEGRN= (  0, 200,   0)
GRAY   = (150, 150, 150)

catImg = pygame.image.load('cat.png')   #current player avatar(cat image for now)

catx = 2             #player coordinates(x-axis)
caty = 325           #player coordinates(y-axis)

window_width = 700   #dimensions(width)
window_height = 400  #dimensions(height)

screen = pygame.display.set_mode((window_width, window_height))   #setting window dimensions
screen.fill(BLACK)                                                #fill screen
pygame.display.set_caption("Platformer")                          #title caption

end = False

while not end:
    screen.fill(BLACK)  # fill screen with black background
    fonttxt = pygame.font.SysFont("Britannic Bold", 40)  #font
    welcomelbl = fonttxt.render("Platformer", 1, WHITE)  #game label
    startlbl = fonttxt.render("Start(Left Click)", 1, WHITE)  #start label and instructions to start
    quitlbl = fonttxt.render("Quit(Press Q)", 1, WHITE)       #quit label and instructions to quit
    instructlbl = fonttxt.render("Instructions:Jump as far as you can without falling", 1, WHITE)
    for event in pygame.event.get():     #when an event happens,
        if event.type == MOUSEBUTTONDOWN:    #specifically left mouse click,
            end = True                       #make while loop end by setting end to True
        elif event.type == KEYUP:  # if a key is pressed,
            if event.key == K_q:   # if it is the 'q' key specifically,
                pygame.quit()  # quit pygame engine,
                sys.exit()     # exit program
        elif event.type == pygame.QUIT:  # when a quit event occurs,
            pygame.quit()  # quit pygame engine,
            sys.exit()     # exit program
    screen.blit(welcomelbl, (200, 50))  # Blit title label
    screen.blit(startlbl, (200, 100))    # Blit start label
    screen.blit(quitlbl, (200, 150))     # Blit quit label
    screen.blit(instructlbl, (5, 200))  # Blit instructions label
    pygame.display.flip()  # flip display

endit = False     #keeps second while loop running

while not endit:
    screen.fill(BLACK)
    screen.blit(catImg, (catx, caty))
    pygame.draw.line(screen, WHITE, (100, 200), (200, 200), 5)
    pygame.draw.line(screen, WHITE, (300, 250), (350, 250), 5)
    pygame.display.update()
    pygame.mixer.init()
    pygame.mixer.music.load('Soft-background-music.wav')  # background music
    pygame.mixer.music.play(-1, 0.0)
    keys = pygame.key.get_pressed()  # checking pressed keys
    if keys[pygame.K_UP]:     #up movement
        caty -= 4
    if keys[pygame.K_DOWN]:   #down movement
        caty += 4
    if keys[pygame.K_RIGHT]:  #right movement
        catx += 4
    if keys[pygame.K_LEFT]:   #left movement
        catx -= 4
    FPS = 100                         #setting Frame rate
    if catx <= 1:                     #if player hits left edge of screen, then prevent them from moving off screen
        catx = 2                      #do so by setting x coordinate to 2(left edge of screen)
    elif catx >= 580:                 #if player hits right edge of screen, then move to next screen
        endit = True                  #do so by ending loop by setting the endit variable to True
    if caty >= 326:                   #if player hits bottom edge of screen, then prevent them from moving off screen
        caty = 325                    #do so by setting y coordinate to 329(bottom edge of screen)
    elif caty <= 1:                   #if player hits top edge of screen, then prevent them from moving off screen
        caty = 2                      #do so by setting y coordinate to 2(top edge of screen)
    if catx >= 100:
        if catx <= 200:
            if caty == 200:
                caty = 199
    elif catx >= 300:
        if catx <= 350:
            if caty == 250:
                caty = 249
    fpsClock = pygame.time.Clock()
    for event in pygame.event.get():       #event handler
        if event.type == pygame.QUIT:      #quit event
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == K_SPACE:       #spacebar action(jumping)
                caty -= 50
        elif event.type == pygame.KEYUP:
            if event.key == K_SPACE:
                caty += 50
    fpsClock.tick(FPS)

catx = 2
caty = 325
screen.blit(catImg, (catx, caty))
pygame.display.update()

while True:
    screen.fill(BLACK)
    screen.blit(catImg, (catx, caty))
    pygame.draw.line(screen, WHITE, (50, 50), (100, 50), 5)
    pygame.draw.line(screen, WHITE, (75, 125), (150, 125), 5)
    pygame.display.update()
    keys = pygame.key.get_pressed()  # checking pressed keys
    if keys[pygame.K_UP]:  # up movement
        caty -= 4
    if keys[pygame.K_DOWN]:  # down movement
        caty += 4
    if keys[pygame.K_RIGHT]:  # right movement
        catx += 4
    if keys[pygame.K_LEFT]:  # left movement
        catx -= 4
    FPS = 100  # setting Frame rate
    if catx <= 1:      # if player hits left edge of screen, then prevent them from moving off screen
        catx = 2       # do so by setting x coordinate to 2(left edge of screen)
    elif catx >= 580:  # if player hits right edge of screen, then move to next screen
        catx = 579     # do so by setting x to 579(right edge of screen)
    if caty >= 326:    # if player hits bottom edge of screen, then prevent them from moving off screen
        caty = 325     # do so by setting y coordinate to 329(bottom edge of screen)
    elif caty <= 1:    # if player hits top edge of screen, then prevent them from moving off screen
        caty = 2       # do so by setting y coordinate to 2(top edge of screen)
    if catx >= 50:
        if catx <= 100:
            if caty == 50:
                caty = 49
    if catx >= 75:
        if catx <= 150:
            if caty == 125:
                caty = 124
    fpsClock = pygame.time.Clock()
    for event in pygame.event.get():  # event handler
        if event.type == pygame.QUIT:  # quit event
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == K_SPACE:  # spacebar action(jumping)
                caty -= 50
        elif event.type == pygame.KEYUP:
            if event.key == K_SPACE:
                caty += 50
    fpsClock.tick(FPS)